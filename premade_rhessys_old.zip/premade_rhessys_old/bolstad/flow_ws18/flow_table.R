


w = read.table("ws18Bolstad.flow", fill=T,skip=1)
cond = !is.na(w[,11])

wtf = w[cond,]; colnames(wtf)=c('fromPatch','fromZone','fromHill','x','y','z','area1','area2','dtype','fromGamma','numFlowOut')
# dtype: 0=land, 2=road, 1=stream (https://github.com/RHESSys/RHESSys/blob/master/rhessys/include/rhessys.h#L1690)


wtf[wtf[,'dtype']==1,]
