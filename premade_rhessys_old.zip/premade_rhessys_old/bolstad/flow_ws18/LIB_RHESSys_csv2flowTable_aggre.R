source("~/Dropbox/LIB_Rscript/LIB_misc.r")
source("~/Dropbox/LIB_Rscript/LIB_dailytimeseries2.r")
arg=commandArgs(T)
 
 
comm = read.csv("cwt_bolstadComm.txt",skip=6,header=F)
dist = read.csv('cwt250Dist.txt',skip=6,header=F)
s218 = c(217992, 218674, 219358, 219359)
s318 = c(226202, 225517, 225518, 225519, 226201, 226203, 226885, 226886, 226887)
s118 = c(197474, 196789, 196790, 196791, 197473, 197475, 198157, 198158, 198159)
	table(comm[,5])
	# -9999     1     2     3     4     8    10 
	 # 4072 14376 83800 40257 20230   762  2940 
	 
	# table(comm[comm[,4]%in%s218,5]) # all 3
	# table(comm[comm[,4]%in%s318,5]) # 2 and 3
	# table(comm[comm[,4]%in%s118,5]) # 2 3 4

# system(paste('Rscript LIB_RHESSys_flowTable2csv.R flow_ws18_bolstad/ws18Bolstad.flow flow_ws18_bolstad/ws18Bolstad.flow',sep=''))
# flowcsv_ = as.matrix(read.csv(paste('flow_ws18_bolstad/ws18Bolstad.flow.csv',sep="")))
# outputfile = paste('flow_ws18_bolstad/ws18Bolstad_aggre.flow',sep="") 
# outputfileCheck = paste('flow_ws18_bolstad/ws18Bolstad_debug.flow.csv',sep="") 

system(paste('Rscript LIB_RHESSys_flowTable2csv.R flow_nlcd/world1000.flow flow_nlcd/world1000.flow',sep=''))
flowcsv_ = as.matrix(read.csv(paste('flow_nlcd/world1000.flow.csv',sep="")))
outputfile = paste('flow_nlcd/world1000_aggre.flow',sep="") 
outputfileCheck = paste('flow_nlcd/world1000_debug.flow.csv',sep="") 

	flowTableFromPatch = flowcsv_[,'fromPatch']
	aggreIDlbl = rep(0,length(flowTableFromPatch))	
	
		## forming aggrePatch
		w = cbind(	
				comm[match(flowTableFromPatch, comm[,4]),5],
				dist[match(flowTableFromPatch, dist[,4]),5]); 
		colnames(w)=c('overID','dist')
		
		cond = w[,'overID']==3 & w[,'dist']>0 # near stream
		aggreIDlbl[cond] = 2000 # cove
		
		cond = w[,'overID']==2 & w[,'dist']>0 # mid slope
		aggreIDlbl[cond] = 3000 # mix
		
		cond = w[,'overID']==4 & w[,'dist']>0 # uphill
		aggreIDlbl[cond] = 1000 # xeric
		
		cond = flowTableFromPatch%in%s218; table(aggreIDlbl[cond])
		aggreIDlbl[cond] = aggreIDlbl[cond] + 218
		
		cond = flowTableFromPatch%in%s318; table(aggreIDlbl[cond])
		aggreIDlbl[cond] = aggreIDlbl[cond] + 318 
		
		cond = flowTableFromPatch%in%s118; table(aggreIDlbl[cond])
		aggreIDlbl[cond] = aggreIDlbl[cond] + 118 
		
		table(aggreIDlbl)
# aggreIDlbl
   # 0 1000 1118 2000 2118 2218 2318 3000 3118 3318 
 # 426  975   16 2591   16   32   24 5432   32   48 

	aggreID = unique(aggreIDlbl)
	aggreID_storedIndex = cbind(aggreID, (1:length(aggreID)-1)) 
	aggreID_storedlbl = aggreID_storedIndex[match(aggreIDlbl, aggreID_storedIndex[,1]),2]
	flowcsv = cbind(flowcsv_, aggreIDlbl, aggreID_storedlbl)
		
	write.csv(flowcsv, outputfileCheck,row.names=F)



##--------------------------------------------------------------------------------------------
##------------------------------------------ output flow table; careful about the "ORDER"
##--------------------------------------------------------------------------------------------
patchID = unique(flowcsv[,'fromPatch']) # this may screw the order
numPatch = length(patchID)
write(numPatch, outputfile,ncolumns=1,sep=" ",append=F )
lineNo =1; jj=1
while(jj <= numPatch){
	
	main = flowcsv[lineNo,c('fromPatch','fromZone','fromHill','x','y','z','area1','area2','dtype','fromGamma','numFlowOut','aggreIDlbl','aggreID_storedlbl')]
	#write(main, outputfile,ncolumns=length(main),sep=" ",append=T ) ## need format %d %d %d %lf %lf %lf %lf %lf %d %lf %d %d
	write(sprintf('%d %d %d %f %f %f %f %f %d %f %d %d %d', main[1], main[2], main[3], main[4],main[5], main[6], main[7], main[8],main[9], main[10], main[11], main[12],main[13]), outputfile,append=T)
	
	drainType = as.numeric(main['dtype'])
	numFlowOut = as.numeric(main['numFlowOut'])
		for(j in 1:numFlowOut){
			toline = flowcsv[lineNo+j-1,c('toPatch','toZone','toHill','gamma')]
			#write(toline, outputfile,ncolumns=length(toline),sep="\t",append=T ) ## need format %d %d %d %lf
			write(sprintf('%d %d %d %f', toline[1], toline[2], toline[3], toline[4]),outputfile,append=T)
		}#j
	lineNo = lineNo + numFlowOut	
	if(drainType==2){
		toline = flowcsv[lineNo,c('toPatch','toZone','toHill','gamma')]
		write(sprintf('%d %d %d %f', toline[1], toline[2], toline[3], toline[4]),outputfile,append=T)
		print(sprintf('print toRoad (%d): %d %d %d %f', lineNo, toline[1], toline[2], toline[3], toline[4]))
		lineNo = lineNo + 1
	}
	jj=jj+1	
}#while jj

  
 
 