arg=commandArgs(T)
#arg=c("lakepatch_2010_4918244.flow")



inputfile=paste(arg[1],sep="")
outputfile=paste(arg[1],".csv",sep="")

con=file(inputfile)
open(con)
realLineNum = 0

w = readLines(con,n=1,warn=F); realLineNum= realLineNum+1 # first line is the number of patch in this file
numPatch= as.numeric(unlist(strsplit(w," +"))[2])
i=1

write(
	c(	'fromPatch','fromZone','fromHill',
		'x','y','z','area1',
		'area2','dtype','fromGamma','numFlowOut',
		'toPatch','toZone','toHill','gamma','withinOrder'
	), outputfile,ncolumns=16,sep=",",append=F )  #12
	
	

while(i<=numPatch){

	w = unlist(strsplit(readLines(con,n=1,warn=F)," +")); realLineNum= realLineNum+1
	if(length(w)>5 ){
		## current patch (from patch)
			# w[2:4] #patch zone hill
			# w[5:12] # some information about this patch
		patchID = as.numeric(w[2])
		numDir=as.numeric(w[12]) #
		drainType = as.numeric(w[10])
		for(j in 1: numDir){
			ww = unlist(strsplit(readLines(con,n=1,warn=F)," +")); realLineNum= realLineNum+1
			write(c(w[2:12],ww[2:5],j), outputfile,ncolumns=16,sep=",",append=T )  #12
		}
		if(drainType==2){
			# road
			ww = unlist(strsplit(readLines(con,n=1,warn=F)," +")); realLineNum= realLineNum+1
			write(c(w[2:12],ww[2:5],j+1), outputfile,ncolumns=16,sep=",",append=T )  #12
		}
		
	}else{
	    print(sprintf('error in reading (%d) %d %d\n', realLineNum, drainType, patchID ));
	}
	
	i=i+1
	
	
}#i

close(con)


